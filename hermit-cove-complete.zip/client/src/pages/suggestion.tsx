import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Suggestion, UserReflection, User } from "@shared/schema";

interface SuggestionPageProps {
  params: {
    week: string;
    day: string;
  };
}

export default function SuggestionPage({ params }: SuggestionPageProps) {
  const [, navigate] = useLocation();
  const [reflection, setReflection] = useState("");
  const [userId, setUserId] = useState<string | null>(null);
  const [showSkipDialog, setShowSkipDialog] = useState(false);
  const [skipReflection, setSkipReflection] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const week = parseInt(params.week);
  const day = parseInt(params.day);

  // All hooks must be called before any early returns
  useEffect(() => {
    const storedUserId = localStorage.getItem("hermitCoveUserId");
    if (!storedUserId) {
      navigate("/");
      return;
    }
    setUserId(storedUserId);
  }, [navigate]);

  const { data: suggestion, isLoading: suggestionLoading } = useQuery<Suggestion>({
    queryKey: ["/api/suggestions/week", week, "day", day],
    enabled: !!week && !!day,
  });

  const { data: user } = useQuery<User>({
    queryKey: ["/api/users", userId],
    enabled: !!userId,
  });

  const { data: existingReflection, isLoading: reflectionLoading } = useQuery<UserReflection>({
    queryKey: ["/api/reflections", userId, suggestion?.id],
    enabled: !!userId && !!suggestion?.id,
  });

  const submitReflectionMutation = useMutation({
    mutationFn: async (reflectionData: { reflection: string; skipRefetch?: boolean }) => {
      if (!suggestion || !userId) throw new Error("Missing data");
      
      const res = await apiRequest("/api/reflections", {
        method: "POST",
        body: {
          userId,
          suggestionId: suggestion.id,
          reflection: reflectionData.reflection,
          completed: false,
        }
      });
      return { ...res, skipRefetch: reflectionData.skipRefetch };
    },
    onSuccess: (data) => {
      // Don't refetch if we're about to navigate away (prevents flash of AI response)
      if (!data?.skipRefetch) {
        queryClient.invalidateQueries({ queryKey: ["/api/reflections", userId, suggestion?.id] });
      }
    },
  });

  const completeSuggestionMutation = useMutation({
    mutationFn: async () => {
      if (!userId || !suggestion) throw new Error("Missing data");
      
      const res = await apiRequest(`/api/users/${userId}/complete-suggestion`, {
        method: "POST",
        body: {
          suggestionId: suggestion.id,
        }
      });
      return res;
    },
    onSuccess: async (updatedUser: User) => {
      // Update user cache immediately with returned data to prevent race conditions
      queryClient.setQueryData(["/api/users", userId], updatedUser);
      
      // Navigate based on updated user's position (use server state, not local math)
      const nextWeek = updatedUser.currentWeek;
      const nextDay = updatedUser.currentSuggestion;
      
      // If we just finished day 7, we should go to week completion
      if (day >= 7) {
        navigate(`/week/${week}/complete`);
      } else {
        navigate(`/suggestion/${nextWeek}/${nextDay}`);
      }
      
      toast({
        title: "Suggestion completed! 🦀",
        description: "Great progress! Keep swimming forward.",
      });
    },
  });

  const skipSuggestionMutation = useMutation({
    mutationFn: async (skipReflectionText?: string) => {
      if (!userId || !suggestion) throw new Error("Missing data");
      
      // If user provided a reflection about why they're skipping, save it first
      if (skipReflectionText && skipReflectionText.trim()) {
        await apiRequest("/api/reflections", {
          method: "POST",
          body: {
            userId,
            suggestionId: suggestion.id,
            reflection: skipReflectionText.trim(),
            completed: false,
          }
        });
      }
      
      const res = await apiRequest(`/api/users/${userId}/skip-suggestion`, {
        method: "POST",
        body: {
          week,
          day,
        }
      });
      return res;
    },
    onSuccess: async (updatedUser: User) => {
      // Update user cache immediately with returned data to prevent race conditions
      queryClient.setQueryData(["/api/users", userId], updatedUser);
      
      setShowSkipDialog(false);
      setSkipReflection("");
      
      // Navigate based on updated user's position (use server state, not local math)
      const nextWeek = updatedUser.currentWeek;
      const nextDay = updatedUser.currentSuggestion;
      
      if (day >= 7) {
        navigate(`/week/${week}/complete`);
      } else {
        navigate(`/suggestion/${nextWeek}/${nextDay}`);
      }
      
      toast({
        title: "Suggestion skipped",
        description: "That's okay! You can always come back to this one later. Keep going! 🌊",
      });
    },
  });
  
  const handleSkipClick = () => {
    // If user already has a reflection written in the main textarea, use that
    if (reflection.trim()) {
      skipSuggestionMutation.mutate(reflection);
    } else {
      // Otherwise show dialog to encourage them to share their feelings
      setShowSkipDialog(true);
    }
  };
  
  const handleConfirmSkip = () => {
    skipSuggestionMutation.mutate(skipReflection);
  };

  // Set reflection from existing data and clear when changing suggestions
  useEffect(() => {
    if (existingReflection?.reflection) {
      setReflection(existingReflection.reflection);
    } else {
      setReflection("");
    }
  }, [existingReflection, suggestion?.id]);

  const isLoading = suggestionLoading || reflectionLoading;

  if (!userId) {
    return null;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen wave-pattern p-4">
        <div className="container mx-auto max-w-4xl">
          <Skeleton className="h-8 w-32 mb-4" />
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  if (!suggestion) {
    return (
      <div className="min-h-screen wave-pattern p-4">
        <div className="container mx-auto max-w-4xl text-center">
          <Card className="p-8">
            <CardContent>
              <p className="text-muted-foreground">Suggestion not found.</p>
              <Button onClick={() => navigate("/dashboard")} className="mt-4">
                Return to Dashboard
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Check if user has access to this suggestion
  const userCanAccess = user && (
    (user.currentWeek > week) ||
    (user.currentWeek === week && user.currentSuggestion >= day)
  );

  if (!userCanAccess) {
    return (
      <div className="min-h-screen wave-pattern p-4 pb-24">
        <div className="container mx-auto max-w-4xl text-center">
          <Card className="p-8">
            <CardContent>
              <div className="text-6xl mb-4">🔒</div>
              <h2 className="text-2xl font-bold text-foreground mb-4">
                This suggestion is locked
              </h2>
              <p className="text-muted-foreground mb-6">
                Complete your current suggestions to unlock this one.
              </p>
              <Button onClick={() => navigate("/dashboard")}>
                Go back to main page
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }


  const handleCompleteAndContinue = async () => {
    if (!existingReflection?.reflection && !reflection.trim()) {
      toast({
        title: "Reflection required",
        description: "Please write a reflection before completing this suggestion.",
        variant: "destructive",
      });
      return;
    }

    // If there's a new reflection that hasn't been submitted, submit it first
    // Skip refetch since we're navigating away (prevents flash of AI response)
    if (reflection.trim() && reflection !== existingReflection?.reflection) {
      try {
        await submitReflectionMutation.mutateAsync({ 
          reflection: reflection.trim(),
          skipRefetch: true 
        });
      } catch (error) {
        console.error("Failed to submit reflection:", error);
        // Continue with completion even if reflection submission fails
      }
    }

    completeSuggestionMutation.mutate();
  };

  return (
    <div className="min-h-screen wave-pattern p-4 pb-24">
      <div className="container mx-auto max-w-4xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate("/dashboard")}
            data-testid="button-back"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Dashboard
          </Button>
          <div className="flex-1">
            <h1 
              className="text-2xl font-bold text-foreground"
              data-testid="page-title"
            >
              Week {week}, Day {day}
            </h1>
            <p className="text-muted-foreground" data-testid="suggestion-category">
              {suggestion.category} • {suggestion.title}
            </p>
          </div>
        </div>

        {/* Main Suggestion Card */}
        <Card className="rounded-2xl mb-6 border border-border shadow-sm">
          <CardContent className="p-8">
            <div className="flex items-start gap-4 mb-6">
              <span className="text-3xl">💡</span>
              <div className="flex-1">
                <h2 
                  className="text-xl font-semibold text-foreground mb-3"
                  data-testid="suggestion-title"
                >
                  {suggestion.title}
                </h2>
                <p 
                  className="text-foreground/80 leading-relaxed mb-6"
                  data-testid="suggestion-description"
                >
                  {suggestion.description}
                </p>
                
                {/* Reflection Area */}
                <div className="bg-card rounded-xl p-6 border border-border">
                  <Label 
                    htmlFor="reflection" 
                    className="block text-sm font-medium text-foreground mb-3"
                  >
                    How do you feel about this suggestion? 🌊
                  </Label>
                  <Textarea
                    id="reflection"
                    value={reflection}
                    onChange={(e) => setReflection(e.target.value)}
                    placeholder="Share your thoughts, concerns, or feelings about this exercise..."
                    className="min-h-24 mb-4"
                    data-testid="textarea-reflection"
                  />
                  
                  
                  {/* AI Response */}
                  {existingReflection?.aiResponse && (
                    <div 
                      className="bg-primary/5 rounded-lg p-4 border-l-4 border-primary mb-4"
                      data-testid="ai-response-container"
                    >
                      <div>
                        <p className="text-sm font-medium text-foreground mb-1">
                          AI Encouragement
                        </p>
                        <p 
                          className="text-sm text-foreground/80"
                          data-testid="ai-response-text"
                        >
                          {existingReflection.aiResponse}
                        </p>
                      </div>
                    </div>
                  )}
                  
                  {/* Action Buttons */}
                  <div className="flex gap-3 flex-wrap">
                    {existingReflection?.completed ? (
                      <Button
                        onClick={() => {
                          // Navigate to next suggestion or week completion
                          if (day >= 7) {
                            navigate(`/week/${week}/complete`);
                          } else {
                            navigate(`/suggestion/${week}/${day + 1}`);
                          }
                        }}
                        data-testid="button-continue-journey"
                      >
                        Continue Journey 🌊
                      </Button>
                    ) : (
                      <>
                        <Button
                          onClick={handleCompleteAndContinue}
                          disabled={completeSuggestionMutation.isPending || skipSuggestionMutation.isPending}
                          data-testid="button-complete-suggestion"
                        >
                          {completeSuggestionMutation.isPending 
                            ? "Completing..." 
                            : "Mark Complete & Continue 🌊"
                          }
                        </Button>
                        <Button
                          variant="secondary"
                          onClick={handleSkipClick}
                          disabled={skipSuggestionMutation.isPending || completeSuggestionMutation.isPending}
                          data-testid="button-skip-suggestion"
                        >
                          {skipSuggestionMutation.isPending 
                            ? "Skipping..." 
                            : "Skip This One"
                          }
                        </Button>
                      </>
                    )}
                    <Button
                      variant="outline"
                      onClick={() => navigate("/dashboard")}
                      data-testid="button-back-to-main"
                    >
                      Go back to main page
                    </Button>
                  </div>
                  
                  {/* Skip explanation */}
                  {!existingReflection?.completed && (
                    <p className="text-xs text-muted-foreground mt-3 text-center">
                      Feeling overwhelmed? It's okay to skip suggestions that feel too challenging right now. Your progress is personal, not perfect.
                    </p>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between items-center">
          <Button
            variant="ghost"
            onClick={() => {
              if (day > 1) {
                navigate(`/suggestion/${week}/${day - 1}`);
              } else if (week > 1) {
                navigate(`/suggestion/${week - 1}/7`);
              } else {
                navigate("/dashboard");
              }
            }}
            disabled={week === 1 && day === 1}
            data-testid="button-previous"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Previous
          </Button>
          
          <div className="text-center">
            <p className="text-sm text-muted-foreground">
              Suggestion {((week - 1) * 7) + day} of 42
            </p>
            <div className="w-32 bg-muted rounded-full h-2 mt-1">
              <div 
                className="bg-primary h-2 rounded-full transition-all duration-300" 
                style={{ width: `${(((week - 1) * 7) + day) / 42 * 100}%` }}
              />
            </div>
          </div>

          <Button
            variant="ghost"
            onClick={() => {
              if (day < 7) {
                navigate(`/suggestion/${week}/${day + 1}`);
              } else if (week < 6) {
                navigate(`/suggestion/${week + 1}/1`);
              }
            }}
            disabled={week === 6 && day === 7}
            data-testid="button-next"
          >
            Next
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
      
      {/* Skip Reflection Dialog */}
      <Dialog open={showSkipDialog} onOpenChange={setShowSkipDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Before you skip... 💭</DialogTitle>
            <DialogDescription>
              It's completely okay to skip this suggestion. Before you go, would you like to share how you're feeling about it? This can help you process your thoughts and track your journey.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <Textarea
              value={skipReflection}
              onChange={(e) => setSkipReflection(e.target.value)}
              placeholder="What's making this feel challenging right now? (optional)"
              className="min-h-24"
              data-testid="textarea-skip-reflection"
            />
            <p className="text-xs text-muted-foreground">
              This is optional - you can skip without writing anything. But sharing your feelings can be part of your healing journey.
            </p>
          </div>
          
          <DialogFooter className="flex gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={() => setShowSkipDialog(false)}
              data-testid="button-cancel-skip"
            >
              Go Back
            </Button>
            <Button
              onClick={handleConfirmSkip}
              disabled={skipSuggestionMutation.isPending}
              data-testid="button-confirm-skip"
            >
              {skipSuggestionMutation.isPending ? "Skipping..." : "Skip & Continue"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
