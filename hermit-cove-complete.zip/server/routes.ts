import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage, createTestUser } from "./storage";
import { generateEncouragement, generateJournalEncouragement } from "./services/openai";
import { 
  insertUserSchema, 
  insertUserReflectionSchema, 
  insertJournalEntrySchema,
  insertWeeklyCompletionSchema,
  insertFeedbackSchema
} from "@shared/schema";

// Admin authentication middleware
function requireAdminAuth(req: Request, res: Response, next: NextFunction) {
  const rawAdminToken = process.env.ADMIN_TOKEN;
  
  if (!rawAdminToken) {
    console.error('ADMIN_TOKEN environment variable is not set');
    return res.status(500).json({ 
      error: 'Configuration error', 
      message: 'Server configuration issue' 
    });
  }
  
  // Normalize admin token
  const adminToken = rawAdminToken.trim().replace(/^"|"$/g, '');
  
  // Get token from Authorization header
  const authHeader = req.headers.authorization;
  const headerToken = authHeader?.replace('Bearer ', '');
  
  if (!headerToken || headerToken !== adminToken) {
    return res.status(401).json({ 
      error: 'Unauthorized', 
      message: 'Admin authentication required' 
    });
  }
  
  next();
}

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Health check for autoscale deployment
  app.get("/health", (_req, res) => {
    res.status(200).send("ok");
  });
  
  // Create or get user
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error) {
      res.status(400).json({ error: "Invalid user data" });
    }
  });

  // Create test user with all suggestions completed (for testing celebration page)
  app.post("/api/users/test-complete", async (req, res) => {
    try {
      const userId = await createTestUser();
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to create test user" });
    }
  });

  // Submit feedback from users
  app.post("/api/feedback", async (req, res) => {
    try {
      const feedbackData = insertFeedbackSchema.parse({
        message: req.body.message,
        userAgent: req.get('User-Agent')
      });
      
      // Save feedback to database
      const savedFeedback = await storage.createFeedback(feedbackData);
      
      res.json({ success: true, message: "Feedback sent successfully", feedback: savedFeedback });
    } catch (error) {
      console.error('Error sending feedback:', error);
      res.status(500).json({ error: "Failed to submit feedback" });
    }
  });

  // Get all feedback
  app.get("/api/feedback", async (req, res) => {
    try {
      const allFeedback = await storage.getAllFeedback();
      res.json(allFeedback);
    } catch (error) {
      console.error('Error fetching feedback:', error);
      res.status(500).json({ error: "Failed to fetch feedback" });
    }
  });

  // Get user
  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user" });
    }
  });

  // Update user progress
  app.patch("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.updateUser(req.params.id, req.body);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to update user" });
    }
  });

  // Get all suggestions
  app.get("/api/suggestions", async (req, res) => {
    try {
      const suggestions = await storage.getAllSuggestions();
      res.json(suggestions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch suggestions" });
    }
  });

  // Get suggestion by week and day
  app.get("/api/suggestions/week/:week/day/:day", async (req, res) => {
    try {
      const week = parseInt(req.params.week);
      const day = parseInt(req.params.day);
      const suggestion = await storage.getSuggestionByWeekAndDay(week, day);
      if (!suggestion) {
        return res.status(404).json({ error: "Suggestion not found" });
      }
      res.json(suggestion);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch suggestion" });
    }
  });

  // Submit reflection with AI response (AI runs in background for faster response)
  app.post("/api/reflections", async (req, res) => {
    try {
      const reflectionData = insertUserReflectionSchema.parse(req.body);
      const reflection = await storage.createUserReflection(reflectionData);
      
      // Get the suggestion for context
      const suggestion = await storage.getSuggestion(reflectionData.suggestionId);
      if (!suggestion) {
        return res.status(404).json({ error: "Suggestion not found" });
      }

      // Return immediately - AI encouragement runs in background
      res.json(reflection);

      // Generate AI encouragement in background (don't block response)
      generateEncouragement(reflectionData.reflection, suggestion.description)
        .then(async (encouragement) => {
          await storage.updateUserReflection(reflection.id, {
            aiResponse: encouragement.message,
            sentiment: encouragement.sentiment
          });
        })
        .catch((error) => {
          console.error('Failed to generate encouragement:', error);
        });
    } catch (error) {
      console.error('Error creating reflection:', error);
      res.status(500).json({ error: "Failed to create reflection" });
    }
  });

  // Get user reflections with suggestion details
  app.get("/api/users/:userId/reflections", async (req, res) => {
    try {
      const reflections = await storage.getUserReflections(req.params.userId);
      
      // Enrich reflections with suggestion details
      const enrichedReflections = await Promise.all(
        reflections.map(async (reflection) => {
          const suggestion = await storage.getSuggestion(reflection.suggestionId);
          return {
            ...reflection,
            suggestion: suggestion || null,
          };
        })
      );
      
      res.json(enrichedReflections);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch reflections" });
    }
  });

  // Get specific reflection
  app.get("/api/reflections/:userId/:suggestionId", async (req, res) => {
    try {
      const reflection = await storage.getUserReflection(req.params.userId, req.params.suggestionId);
      if (!reflection) {
        return res.status(404).json({ error: "Reflection not found" });
      }
      res.json(reflection);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch reflection" });
    }
  });

  // Complete suggestion and update user progress
  app.post("/api/users/:userId/complete-suggestion", async (req, res) => {
    try {
      const { suggestionId } = req.body;
      const userId = req.params.userId;
      
      // Mark reflection as completed
      const reflection = await storage.getUserReflection(userId, suggestionId);
      if (reflection) {
        await storage.updateUserReflection(reflection.id, { completed: true });
      }
      
      // Update user progress
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const completedSuggestions = user.completedSuggestions + 1;
      
      // Calculate what the next suggestion should be
      let nextWeek = user.currentWeek;
      let nextDay = user.currentSuggestion;
      
      // If we just completed the last day of the week (day 7), advance to next week
      if (user.currentSuggestion >= 7) {
        nextWeek = Math.min(user.currentWeek + 1, 6);
        nextDay = 1;
      } else {
        // Otherwise, just advance to the next day in the current week
        nextDay = user.currentSuggestion + 1;
      }

      const updatedUser = await storage.updateUser(userId, {
        completedSuggestions,
        currentWeek: nextWeek,
        currentSuggestion: nextDay
      });

      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ error: "Failed to complete suggestion" });
    }
  });

  // Skip suggestion and advance user progress (skips count toward week/course completion)
  app.post("/api/users/:userId/skip-suggestion", async (req, res) => {
    try {
      const userId = req.params.userId;
      const { week, day } = req.body;
      
      // Validate week and day are provided
      if (!week || !day) {
        return res.status(400).json({ error: "Week and day are required" });
      }
      
      // Get user
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      // Only advance if this is the user's current suggestion (prevent skipping already completed suggestions)
      if (user.currentWeek !== week || user.currentSuggestion !== day) {
        // User is viewing an old/already passed suggestion, just return current state
        return res.json(user);
      }

      // Increment completedSuggestions - skips count toward progress!
      const completedSuggestions = user.completedSuggestions + 1;

      // Calculate what the next suggestion should be based on the suggestion being skipped
      let nextWeek = week;
      let nextDay = day;
      
      // If we're on the last day of the week (day 7), advance to next week
      if (day >= 7) {
        nextWeek = Math.min(week + 1, 6);
        nextDay = 1;
      } else {
        // Otherwise, just advance to the next day in the current week
        nextDay = day + 1;
      }

      const updatedUser = await storage.updateUser(userId, {
        completedSuggestions,
        currentWeek: nextWeek,
        currentSuggestion: nextDay
      });

      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ error: "Failed to skip suggestion" });
    }
  });

  // Create journal entry
  app.post("/api/journal", async (req, res) => {
    try {
      const entryData = insertJournalEntrySchema.parse(req.body);
      const entry = await storage.createJournalEntry(entryData);
      
      // Generate AI encouragement for journal entry
      if (entryData.content && entryData.mood) {
        try {
          const encouragement = await generateJournalEncouragement(entryData.content, entryData.mood);
          res.json({ ...entry, aiEncouragement: encouragement });
        } catch (error) {
          console.error('Failed to generate journal encouragement:', error);
          res.json(entry);
        }
      } else {
        res.json(entry);
      }
    } catch (error) {
      console.error('Journal entry creation error:', error);
      res.status(500).json({ error: "Failed to create journal entry" });
    }
  });

  // Get user journal entries
  app.get("/api/users/:userId/journal", async (req, res) => {
    try {
      const entries = await storage.getJournalEntries(req.params.userId);
      res.json(entries);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch journal entries" });
    }
  });

  // Complete week
  app.post("/api/users/:userId/complete-week", async (req, res) => {
    try {
      const completionData = insertWeeklyCompletionSchema.parse({
        userId: req.params.userId,
        ...req.body
      });
      const completion = await storage.createWeeklyCompletion(completionData);
      res.json(completion);
    } catch (error) {
      res.status(500).json({ error: "Failed to complete week" });
    }
  });

  // Get weekly completion
  app.get("/api/users/:userId/weeks/:week/completion", async (req, res) => {
    try {
      const completion = await storage.getWeeklyCompletion(
        req.params.userId, 
        parseInt(req.params.week)
      );
      if (!completion) {
        return res.status(404).json({ error: "Weekly completion not found" });
      }
      res.json(completion);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch weekly completion" });
    }
  });

  // Get all weekly completions for a user
  app.get("/api/users/:userId/weekly-completions", async (req, res) => {
    try {
      const completions = await storage.getAllWeeklyCompletions(req.params.userId);
      res.json(completions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch weekly completions" });
    }
  });

  // Fix user progress (temporary endpoint for debugging)
  app.post("/api/users/:userId/fix-progress", async (req, res) => {
    try {
      const userId = req.params.userId;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      // If user completed 7 suggestions but still on week 1, advance them
      if (user.completedSuggestions >= 7 && user.currentWeek === 1) {
        const updatedUser = await storage.updateUser(userId, {
          currentWeek: 2,
          currentSuggestion: 1
        });
        res.json(updatedUser);
      } else {
        res.json(user);
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to fix progress" });
    }
  });

  // Admin authentication endpoint
  app.post("/api/admin/auth", (req, res) => {
    const { token } = req.body;
    const rawAdminToken = process.env.ADMIN_TOKEN;
    
    if (!rawAdminToken) {
      console.error('ADMIN_TOKEN environment variable is not set');
      return res.status(500).json({ 
        error: 'Configuration error', 
        message: 'Server configuration issue' 
      });
    }
    
    // Normalize tokens by trimming whitespace and removing quotes
    const adminToken = rawAdminToken.trim().replace(/^"|"$/g, '');
    const inputToken = (token || '').trim();
    
    if (!inputToken || inputToken !== adminToken) {
      return res.status(401).json({ 
        error: 'Invalid token', 
        message: 'Please check your admin credentials' 
      });
    }
    
    res.json({ 
      success: true, 
      message: 'Authentication successful',
      token: adminToken // Return token for client to store
    });
  });
  
  // Admin logout endpoint
  app.post("/api/admin/logout", (req, res) => {
    // No server-side action needed for token-based auth
    res.json({ 
      success: true, 
      message: 'Logged out successfully' 
    });
  });

  // Admin endpoints for dashboard analytics (protected)
  app.get("/api/admin/stats", requireAdminAuth, async (req, res) => {
    try {
      const stats = await storage.getAdminStats();
      res.json(stats);
    } catch (error) {
      console.error('Error fetching admin stats:', error);
      res.status(500).json({ error: "Failed to fetch admin statistics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
